package org.cis120;

import java.util.TreeSet;

public class Channel {
    // fields
    private String channelName;
    private boolean privacyStatus;
    private String owner;
    private TreeSet<String> members;

    // constructor

    public Channel(String channelName, boolean privacyStatus, String owner) {
        this.channelName = channelName;
        this.members = new TreeSet<String>();
        members.add(owner);
        this.privacyStatus = privacyStatus;
        this.owner = owner;
    }

    // setters and getters

    public void changeUsername(String oldMember, String newMember) {
        if (this.removeMember(oldMember)) {
            this.addMember(newMember);
        }
        if (this.owner == oldMember) {
            this.owner = newMember;
        }
    }

    // adds a new member of channel
    // this and remove member return booleans because in the case
    // that a new member cannot be added or removed for some reason,
    // we need to know
    public boolean addMember(String member) {
        return members.add(member);
    }

    // gets members of a channel
    public TreeSet<String> getMembers() {
        return this.members;
    }

    // checks if a member is in a channel
    public boolean userInside(String member) {
        return members.contains(member);
    }

    // checks if a channel is private or not
    public boolean getChanPrivacy() {

        return this.privacyStatus;
    }

    // gets name of channel
    public String getChannelName() {
        return this.channelName;
    }

    // gets ownername
    public String getOwner() {
        return this.owner;
    }

    // removes member, returns boolean
    public boolean removeMember(String member) {
        return members.remove(member);
    }

}
