package org.cis120;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Collection;
import java.util.Set;
import java.util.TreeSet;

public class ServerModelTest {
    private ServerModel model;

    /**
     * Before each test, we initialize model to be
     * a new ServerModel (with all new, empty state)
     */
    @BeforeEach
    public void setUp() {
        // We initialize a fresh ServerModel for each test
        model = new ServerModel();
    }

    /**
     * Here is an example test that checks the functionality of your
     * changeNickname error handling. Each line has commentary directly above
     * it which you can use as a framework for the remainder of your tests.
     */
    @Test
    public void testInvalidNickname() {
        // A user must be registered before their nickname can be changed,
        // so we first register a user with an arbitrarily chosen id of 0.
        model.registerUser(0);

        // We manually create a Command that appropriately tests the case
        // we are checking. In this case, we create a NicknameCommand whose
        // new Nickname is invalid.
        Command command = new NicknameCommand(0, "User0", "!nv@l!d!");

        // We manually create the expected Broadcast using the Broadcast
        // factory methods. In this case, we create an error Broadcast with
        // our command and an INVALID_NAME error.
        Broadcast expected = Broadcast.error(
                command, ServerResponse.INVALID_NAME
        );

        // We then get the actual Broadcast returned by the method we are
        // trying to test. In this case, we use the updateServerModel method
        // of the NicknameCommand.
        Broadcast actual = command.updateServerModel(model);

        // The first assertEquals call tests whether the method returns
        // the appropriate Broadcast.
        assertEquals(expected, actual, "Broadcast");

        // We also want to test whether the state has been correctly
        // changed.In this case, the state that would be affected is
        // the user's Collection.
        Collection<String> users = model.getRegisteredUsers();

        // We now check to see if our command updated the state
        // appropriately. In this case, we first ensure that no
        // additional users have been added.
        assertEquals(1, users.size(), "Number of registered users");

        // We then check if the username was updated to an invalid value
        // (it should not have been).
        assertTrue(users.contains("User0"), "Old nickname still registered");

        // Finally, we check that the id 0 is still associated with the old,
        // unchanged nickname.
        assertEquals(
                "User0", model.getNickname(0),
                "User with id 0 nickname unchanged"
        );
    }

    /*
     * Your TAs will be manually grading the tests that you write below this
     * comment block. Don't forget to test the public methods you have added to
     * your ServerModel class, as well as the behavior of the server in
     * different scenarios.
     * You might find it helpful to take a look at the tests we have already
     * provided you with in Task4Test, Task3Test, and Task5Test.
     */
    @Test
    public void testingMsgWithNonExistentChannel() {
        model.registerUser(0);
        model.registerUser(1);
        model.registerUser(2);
        model.registerUser(3);
        model.registerUser(4);
        model.registerUser(5);
        model.registerUser(6);
        model.registerUser(7);
        model.registerUser(8);
        model.registerUser(9);
        model.registerUser(10);
        model.registerUser(11);
        model.registerUser(12);
        model.registerUser(13);
        model.registerUser(14);
        model.registerUser(15);
        model.registerUser(16);
        model.registerUser(17);
        model.registerUser(18);
        model.registerUser(19);
        model.registerUser(20);

        Command mkComm = new CreateCommand(0, "User0", "AChannel", false);
        Command mkComm1 = new CreateCommand(1, "User1", "BChannel", false);

        mkComm.updateServerModel(model);
        mkComm1.updateServerModel(model);

        Command joining = new JoinCommand(1, "User1", "AChannel");
        Command joining1 = new JoinCommand(0, "User0", "BChannel");

        joining.updateServerModel(model);
        joining1.updateServerModel(model);

        Command msg = new MessageCommand(0, "User0", "ZChannel", "hi");
        Broadcast assertion = Broadcast.error(msg, ServerResponse.NO_SUCH_CHANNEL);
        Broadcast actual = msg.updateServerModel(model);
        assertEquals(assertion, actual, "No such channel works correctly");

    }

    @Test
    public void testingMsgWithCorrectChannel() {
        model.registerUser(0);
        model.registerUser(1);
        model.registerUser(2);
        model.registerUser(3);
        model.registerUser(4);
        model.registerUser(5);
        model.registerUser(6);
        model.registerUser(7);
        model.registerUser(8);
        model.registerUser(9);
        model.registerUser(10);
        model.registerUser(11);
        model.registerUser(12);
        model.registerUser(13);
        model.registerUser(14);
        model.registerUser(15);
        model.registerUser(16);
        model.registerUser(17);
        model.registerUser(18);
        model.registerUser(19);
        model.registerUser(20);

        Command mkComm = new CreateCommand(0, "User0", "AChannel", false);
        Command mkComm1 = new CreateCommand(1, "User1", "BChannel", false);

        mkComm.updateServerModel(model);
        mkComm1.updateServerModel(model);

        Command joining = new JoinCommand(0, "User0", "AChannel");
        Command joining2 = new JoinCommand(2, "User2", "AChannel");
        Command joining1 = new JoinCommand(1, "User1", "BChannel");

        joining.updateServerModel(model);
        joining1.updateServerModel(model);
        joining2.updateServerModel(model);

        Set<String> messages = new TreeSet<>();
        messages.add("User0");
        messages.add("User2");

        Command msg = new MessageCommand(0, "User0", "AChannel", "hello");
        Broadcast assertion = Broadcast.okay(msg, messages);
        Broadcast actual = msg.updateServerModel(model);
        assertEquals(assertion, actual, "msg command works correctly");

    }



    @Test
    public void testKickUserPrivateChannel2() {
        model.registerUser(0);
        model.registerUser(1);
        model.registerUser(2);
        model.registerUser(3);

        Command create = new CreateCommand(2, "User2", "private", true);
        create.updateServerModel(model);

        Command invite = new InviteCommand(2, "User2", "private", "User3");
        invite.updateServerModel(model);

        Command command = new KickCommand(2, "User2", "private", "User3");

        assertTrue(model.getUsersInChannel("private").contains("User3"), "private has User3");

        Set<String> recipients = new TreeSet<>();
        recipients.add("User2");
        recipients.add("User3");

        Broadcast expected = Broadcast.okay(command, recipients);
        Broadcast actual = command.updateServerModel(model);
        assertEquals(expected, actual, "Broadcast returns correctly");

        assertTrue(model.getUsersInChannel("private").contains("User2"), "private has User2");
        assertFalse(
                model.getUsersInChannel("private").contains("User3"), "private does not have User3"
        );
        assertEquals(1, model.getUsersInChannel("private").size(), "private correctnum. users");

    }







    @Test
    public void testKickUserKickingWorksMessagesSent() {
        model.registerUser(0);
        model.registerUser(1);
        model.registerUser(2);
        model.registerUser(3);
        model.registerUser(4);
        model.registerUser(5);
        model.registerUser(6);
        model.registerUser(7);
        model.registerUser(8);
        model.registerUser(9);
        model.registerUser(10);
        model.registerUser(11);
        model.registerUser(12);
        model.registerUser(13);
        model.registerUser(14);
        model.registerUser(15);
        model.registerUser(16);
        model.registerUser(17);
        model.registerUser(18);
        model.registerUser(19);
        model.registerUser(20);

        // create channel
        Command channelCreated = new CreateCommand(1, "User1", "AChannel", true);
        channelCreated.updateServerModel(model);
        // invite
        Command invComm = new InviteCommand(1, "User1", "AChannel", "User2");
        Command invComm2 = new InviteCommand(1, "User1", "AChannel", "User3");

        invComm.updateServerModel(model);
        invComm2.updateServerModel(model);

        // kick
        Command command = new KickCommand(1, "User1", "AChannel", "User2");
        // create messageSet with recipients involved
        Set<String> messages = new TreeSet<>();
        messages.add("User1");
        messages.add("User2");
        messages.add("User3");
        // create broadcasts using messageSet
        Broadcast assertion = Broadcast.okay(command, messages);
        Broadcast actual = command.updateServerModel(model);
        // make assertions
        assertFalse(
                model.getUsersInChannel("AChannel").contains("User2"), "AChannel doesn't " +
                        "have User2"
        );
        assertTrue(model.getUsersInChannel("AChannel").contains("User3"), "User3" +
                " kept when kicking another user"
        );
        assertTrue(
                model.getUsersInChannel("AChannel").contains("User1"), "User1 kept when " +
                        "kicking another User"
        );
        assertEquals(
                assertion, actual,
                "Correct messages sent to all members of the channel that someone" +
                        " was kicked from"
        );

    }





}
